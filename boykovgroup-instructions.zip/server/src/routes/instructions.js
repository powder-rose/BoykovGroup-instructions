import { Router } from "express";
import { instructionsRepository } from "../services/instructionsRepository.js";
import { searchInstructions } from "../services/searchService.js";
import { generateInstructionWithYandexGpt, isYandexGptConfigured } from "../services/yandexGptService.js";
import { slugify } from "../utils/slug.js";

export const instructionsRouter = Router();

// GET /api/instructions?q=...&page=1&pageSize=6
// Поиск выполняется полностью на сервере, клиент только отображает результат.
instructionsRouter.get("/", (req, res) => {
  const q = typeof req.query.q === "string" ? req.query.q : "";
  const page = Number.parseInt(req.query.page, 10) || 1;
  const pageSize = Number.parseInt(req.query.pageSize, 10) || 6;

  const result = searchInstructions(q, { page, pageSize });
  res.json(result);
});

// GET /api/instructions/:id — полный текст одной инструкции
instructionsRouter.get("/:id", (req, res) => {
  const instruction = instructionsRepository.getById(req.params.id);
  if (!instruction) {
    return res.status(404).json({ error: "Инструкция не найдена" });
  }
  res.json(instruction);
});

// POST /api/instructions/generate { profession: string }
// Генерирует недостающую инструкцию через YandexGPT и сохраняет её в базу.
instructionsRouter.post("/generate", async (req, res) => {
  const profession = String(req.body?.profession ?? "").trim();
  if (!profession) {
    return res.status(400).json({ error: "Поле profession обязательно" });
  }

  if (!isYandexGptConfigured()) {
    return res.status(503).json({
      error:
        "YandexGPT не настроен на сервере. Задайте YANDEX_API_KEY и YANDEX_FOLDER_ID в server/.env и перезапустите сервер.",
    });
  }

  const id = slugify(profession) || `instruction-${Date.now()}`;

  const existing = instructionsRepository.getById(id);
  if (existing) {
    return res.json(existing);
  }

  try {
    const generated = await generateInstructionWithYandexGpt(profession);
    const instruction = {
      id,
      title: generated.title,
      profession: generated.profession,
      intro: generated.intro,
      sections: generated.sections,
      source: "generated",
      createdAt: new Date().toISOString(),
    };
    instructionsRepository.save(instruction);
    res.status(201).json(instruction);
  } catch (err) {
    console.error("Ошибка генерации инструкции через YandexGPT:", err);
    res.status(502).json({ error: `Не удалось сгенерировать инструкцию: ${err.message}` });
  }
});
