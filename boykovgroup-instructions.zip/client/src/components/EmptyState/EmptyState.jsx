import styles from "./EmptyState.module.css";

export default function EmptyState({ query, isGenerating, error, onGenerate }) {
  return (
    <div className={styles.wrapper}>
      <p className={styles.text}>
        По запросу «{query}» инструкция не найдена.
      </p>
      <button
        type="button"
        className={styles.button}
        onClick={onGenerate}
        disabled={isGenerating}
      >
        {isGenerating ? "Генерируем инструкцию..." : "Сгенерировать инструкцию через YandexGPT"}
      </button>
      {error && <p className={styles.error}>{error}</p>}
    </div>
  );
}
