import styles from "./InstructionButton.module.css";

export default function InstructionButton({ instruction, onClick }) {
  return (
    <button
      type="button"
      className={styles.button}
      onClick={() => onClick(instruction.id)}
    >
      <span>{instruction.title}</span>
      {instruction.source === "generated" && (
        <span className={styles.badge} title="Сгенерировано нейросетью YandexGPT">
          AI
        </span>
      )}
    </button>
  );
}
