import styles from "./SiteLinkButton.module.css";

const SITE_URL = import.meta.env.VITE_SITE_URL || "https://boykovgroup.ru";

/** Логотип-кнопка в шапке: переход на основной сайт компании. */
export default function SiteLinkButton() {
  return (
    <a
      className={styles.button}
      href={SITE_URL}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Перейти на сайт boykovgroup.ru"
    >
      <span className={styles.badge}>Б</span>
      <span className={styles.text}>
        <span className={styles.title}>БОЙКОВГРУПП</span>
        <span className={styles.subtitle}>ООО «СпецКонс»</span>
      </span>
    </a>
  );
}
