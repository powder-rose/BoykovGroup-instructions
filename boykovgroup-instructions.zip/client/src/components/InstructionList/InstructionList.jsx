import InstructionButton from "../InstructionButton/InstructionButton.jsx";
import styles from "./InstructionList.module.css";

export default function InstructionList({ instructions, onSelect }) {
  return (
    <ul className={styles.list}>
      {instructions.map((instruction) => (
        <li key={instruction.id}>
          <InstructionButton instruction={instruction} onClick={onSelect} />
        </li>
      ))}
    </ul>
  );
}
