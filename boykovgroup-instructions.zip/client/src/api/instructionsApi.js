const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:4000";

async function request(path, options = {}) {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });

  if (!response.ok) {
    let message = `Ошибка запроса (${response.status})`;
    try {
      const data = await response.json();
      if (data?.error) message = data.error;
    } catch {
      // тело ответа могло быть пустым — оставляем сообщение по умолчанию
    }
    throw new Error(message);
  }

  return response.json();
}

/**
 * Поиск инструкций — вся логика поиска выполняется на сервере,
 * клиент лишь передаёт текст запроса и номер страницы.
 */
export function searchInstructions({ query = "", page = 1, pageSize = 6 } = {}) {
  const params = new URLSearchParams({
    q: query,
    page: String(page),
    pageSize: String(pageSize),
  });
  return request(`/api/instructions?${params.toString()}`);
}

export function getInstruction(id) {
  return request(`/api/instructions/${encodeURIComponent(id)}`);
}

/** Просит сервер сгенерировать недостающую инструкцию через YandexGPT. */
export function generateInstruction(profession) {
  return request(`/api/instructions/generate`, {
    method: "POST",
    body: JSON.stringify({ profession }),
  });
}
