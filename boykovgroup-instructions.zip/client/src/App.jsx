import { useEffect, useState } from "react";
import Header from "./components/Header/Header.jsx";
import InstructionList from "./components/InstructionList/InstructionList.jsx";
import Pagination from "./components/Pagination/Pagination.jsx";
import Loader from "./components/Loader/Loader.jsx";
import EmptyState from "./components/EmptyState/EmptyState.jsx";
import InstructionModal from "./components/InstructionModal/InstructionModal.jsx";
import { useDebouncedValue } from "./hooks/useDebouncedValue.js";
import { searchInstructions, getInstruction, generateInstruction } from "./api/instructionsApi.js";
import styles from "./App.module.css";

const PAGE_SIZE = 6;

export default function App() {
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const debouncedQuery = useDebouncedValue(query, 350);

  const [result, setResult] = useState({ items: [], total: 0, totalPages: 1 });
  const [isSearching, setIsSearching] = useState(true);
  const [searchError, setSearchError] = useState(null);

  const [isGenerating, setIsGenerating] = useState(false);
  const [generateError, setGenerateError] = useState(null);

  const [selectedId, setSelectedId] = useState(null);
  const [selectedInstruction, setSelectedInstruction] = useState(null);
  const [isLoadingInstruction, setIsLoadingInstruction] = useState(false);
  const [instructionError, setInstructionError] = useState(null);

  // Сбрасываем страницу на первую при каждом новом поисковом запросе.
  useEffect(() => {
    setPage(1);
  }, [debouncedQuery]);

  // Поиск инструкций на сервере при изменении запроса или страницы.
  useEffect(() => {
    let cancelled = false;
    setIsSearching(true);
    setSearchError(null);

    searchInstructions({ query: debouncedQuery, page, pageSize: PAGE_SIZE })
      .then((data) => {
        if (!cancelled) setResult(data);
      })
      .catch((err) => {
        if (!cancelled) setSearchError(err.message);
      })
      .finally(() => {
        if (!cancelled) setIsSearching(false);
      });

    return () => {
      cancelled = true;
    };
  }, [debouncedQuery, page]);

  function handleSelect(id) {
    setSelectedId(id);
    setSelectedInstruction(null);
    setInstructionError(null);
    setIsLoadingInstruction(true);

    getInstruction(id)
      .then((data) => setSelectedInstruction(data))
      .catch((err) => setInstructionError(err.message))
      .finally(() => setIsLoadingInstruction(false));
  }

  function handleCloseModal() {
    setSelectedId(null);
    setSelectedInstruction(null);
    setInstructionError(null);
  }

  async function handleGenerate() {
    setIsGenerating(true);
    setGenerateError(null);
    try {
      const instruction = await generateInstruction(debouncedQuery);
      // Показываем сгенерированную инструкцию сразу и обновляем список поиска.
      setSelectedId(instruction.id);
      setSelectedInstruction(instruction);
      const refreshed = await searchInstructions({ query: debouncedQuery, page: 1, pageSize: PAGE_SIZE });
      setResult(refreshed);
      setPage(1);
    } catch (err) {
      setGenerateError(err.message);
    } finally {
      setIsGenerating(false);
    }
  }

  const showEmptyState = !isSearching && !searchError && debouncedQuery.trim() && result.items.length === 0;

  return (
    <div className={styles.page}>
      <Header query={query} onQueryChange={setQuery} />

      <main>
        {isSearching && <Loader label="Ищем инструкции..." />}

        {!isSearching && searchError && (
          <p className={styles.error}>Не удалось выполнить поиск: {searchError}</p>
        )}

        {!isSearching && !searchError && result.items.length > 0 && (
          <>
            <InstructionList instructions={result.items} onSelect={handleSelect} />
            <Pagination page={result.page} totalPages={result.totalPages} onChange={setPage} />
          </>
        )}

        {showEmptyState && (
          <EmptyState
            query={debouncedQuery}
            isGenerating={isGenerating}
            error={generateError}
            onGenerate={handleGenerate}
          />
        )}
      </main>

      {selectedId && (
        <InstructionModal
          instruction={selectedInstruction}
          isLoading={isLoadingInstruction}
          error={instructionError}
          onClose={handleCloseModal}
        />
      )}
    </div>
  );
}
